//all code is currently in the .h file
#include "ale_c_wrapper.h"

